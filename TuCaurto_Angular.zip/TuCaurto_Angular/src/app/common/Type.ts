export class Type {
  id: number;
  type: string;
  description: string;
}
