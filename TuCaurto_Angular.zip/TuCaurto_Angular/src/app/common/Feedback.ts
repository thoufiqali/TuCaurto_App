export class Feedback{
  id: number;
  name: string;
  email: string;
  message: string;

}
