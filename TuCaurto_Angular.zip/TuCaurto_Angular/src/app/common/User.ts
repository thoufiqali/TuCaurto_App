export class User {
  id: number;

  email: string;

  name: string;
  contactNumber: number;
  gender: string;
  imageUrl: string;
  address: string;
  city: string;
  pincode: number;
  state: string;
}
